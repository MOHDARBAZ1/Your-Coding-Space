const form = document.getElementById("aform");
const userName = document.getElementById("username");
const passWord = document.getElementById("password");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  checkInputs();
});

function checkInputs() {
  const usernameValue = userName.value.trim();
  const passwordValue = passWord.value.trim();

  if (usernameValue === "") {
    alert("Username cannot be blank");
  } else if (passwordValue === "") {
    alert("Username cannot be blank");
  } else if (usernameValue === "arbaz" && passwordValue === "123456") {
    alert("Login Succesfull");
  } else {
    alert("Wrong Username and Password");
  }
}
